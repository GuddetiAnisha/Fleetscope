# FleetScope synthetic demonstration

Model-based 95% uncertainty intervals are heuristic, not calibrated statistical confidence intervals. Sources may be correlated. Coverage correction assumes the observed sample is representative. See README for equations and limitations.
